# CloudPark — Cloud-Based Parking Management System

CloudPark is a college-project demonstration of a responsive parking reservation and administration system. It runs locally with SQLite and can be configured to use PostgreSQL in a hosted environment. Sample parking locations are explicitly labelled demo data. Simulated payments do not charge money; no IoT device or payment gateway is connected.

## Project abstract and objectives

CloudPark demonstrates how a browser-based application can centralize parking locations, slot inventory and time-bounded reservations. A Django server validates user access, reservation time ranges, operating hours, slot conflicts and price calculations before persisting data through the ORM. The project objectives are to demonstrate a cloud-ready application configuration, a shared database-backed workflow, authentication and authorization, responsive web UI, automated tests, and a clear path from local SQLite development to hosted PostgreSQL deployment.

## Implemented features

- Email-based customer registration, login, logout, password change and hashed credentials.
- Customer and administrator roles; registration cannot grant administrator access.
- Protected customer profile editing and password change.
- Demo parking locations and individual car/motorcycle slots.
- Saved vehicles are associated with each customer's bookings.
- Search and time-aware availability backed by booking records.
- Server-validated reservations, unique references, status lifecycle, cancellation cutoff and per-started-hour pricing.
- Booking history, booking detail pages and owner-only access.
- Clearly simulated demo payment records; no real payment integration.
- Protected admin dashboard, location/slot/user/booking/payment views, status actions and CSV export.
- Database-backed dashboard metrics and Chart.js charts; health endpoint at `/health/`.
- PostgreSQL URL support, production static-file handling, environment configuration and deployment guidance.
- Cloud architecture and ER overview at `/architecture/`.

Optional, not implemented: real payment processing, live sensor/IoT integration, email notifications, and actual cloud hosting. Availability is based on reservations, not physical sensors.

## Requirements

- Windows 10/11 and PowerShell
- Python 3.10 or newer (the project was authored/tested with Python 3.11)
- VS Code (recommended)

SQLite is included with Python. PostgreSQL, Docker, paid services and cloud credentials are not needed for local use. Bootstrap, Bootstrap Icons and Chart.js are loaded from their public CDNs in the browser.

## Windows PowerShell setup

Run these commands from the project folder in the VS Code PowerShell terminal:

```powershell
python --version
python -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
pip install -r requirements.txt
if (-not (Test-Path .env)) { Copy-Item .env.example .env }
python manage.py check
python manage.py migrate
python manage.py seed_demo_data
python manage.py createsuperuser
python manage.py runserver
```

The normal local run command, from the project root with the virtual environment activated, is:

```powershell
python manage.py runserver 127.0.0.1:8000
```

Open <http://127.0.0.1:8000/>. The health endpoint is <http://127.0.0.1:8000/health/> and the Django staff admin is at <http://127.0.0.1:8000/django-admin/>. Keep the terminal running while using the site; press `Ctrl+C` to stop the server. If port 8000 is already occupied, run `python manage.py runserver 127.0.0.1:8001` and use port 8001 instead.

The server uses the existing `db.sqlite3`; do not delete it to resolve startup problems. `.env` is optional for local defaults and is ignored by Git. To use local settings from a file, copy `.env.example` once with `Copy-Item .env.example .env`; leave `DATABASE_URL` blank to use SQLite.

If PowerShell blocks venv activation, use this command for the current terminal only, then activate:

```powershell
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
.\.venv\Scripts\Activate.ps1
```

Create an administrator only through `python manage.py createsuperuser`; enter its email, name and password when prompted. Do not put credentials in source files or share the development admin password. Customer accounts can be created at `/register/`.

## Run automated tests

```powershell
python manage.py test
```

The tests cover registration/password hashing, login, role controls, location creation, health, database-backed availability, overlapping reservation rejection, invalid times, price rounding, cancellation, booking ownership and simulated payments.

## Booking lifecycle and rules

New bookings are confirmed atomically after the server rechecks slot status and conflicting active reservations. Pending and confirmed bookings block their slot for overlapping time ranges; cancelled and completed bookings do not. Administrators may transition pending bookings to confirmed/cancelled and confirmed bookings to cancelled/completed. Customer cancellation is allowed only while the reservation is more than `CANCELLATION_CUTOFF_HOURS` (default 2) away. Booking records are retained for history.

The billable duration is rounded up to the next whole hour (a partial started hour costs a full hour); minimum billable duration is one hour. The backend stores the rate snapshot and calculates the total. SQLite is suitable for a single-user demonstration but does not provide PostgreSQL's row-locking guarantees for concurrent requests. For multi-user production booking concurrency, use PostgreSQL and keep the atomic server-side availability check.

## Deploy to Render (PostgreSQL)

This repository is prepared for Render but is **not deployed yet**. Deployment requires your Render account, a connected Git repository and a PostgreSQL database. Do not publish `.env`, `db.sqlite3`, `staticfiles/`, real passwords or secret keys. The `.gitignore` excludes those local files; check Git's pending changes before pushing.

1. Push the project source to GitHub. Keep `.env`, SQLite files, local virtual environments and credentials out of the repository.
2. In Render, create a managed PostgreSQL database and a Python web service connected to the repository. Use the database's **internal** connection URL for a service in the same Render region.
3. Set the Render service's build command to:

   ```text
   pip install -r requirements.txt && python manage.py collectstatic --noinput && python manage.py migrate
   ```

4. Set the start command to bind to Render's assigned port:

   ```text
   gunicorn config.wsgi:application --bind 0.0.0.0:$PORT
   ```

5. Set the health check path in Render's service settings to `/health/`.
6. Configure these service environment variables in Render (never in source code):
   - `DJANGO_SECRET_KEY`: generate a unique random secret in Render.
   - `DJANGO_DEBUG=False`
   - `DJANGO_ALLOWED_HOSTS`: the exact Render hostname, without scheme (for example `cloudpark-example.onrender.com`).
   - `CSRF_TRUSTED_ORIGINS`: the full HTTPS origin (for example `https://cloudpark-example.onrender.com`).
   - `DATABASE_URL`: the PostgreSQL **internal** URL for the Render database.
   - Optional `CANCELLATION_CUTOFF_HOURS=2`.
7. Deploy and inspect the Render build and runtime logs. When deployment is ready, open the assigned HTTPS URL, verify `/health/`, and test registration, login, static styling and reservation flow.
8. Create an administrator securely from the Render shell with `python manage.py createsuperuser`. Run `python manage.py seed_demo_data` there if you want the clearly labelled demo locations on the live site.
9. Enable database backups and review your provider's migration/release process before using real customer data.

Production settings reject missing `DJANGO_SECRET_KEY`, `DJANGO_ALLOWED_HOSTS` or `DATABASE_URL` when `DJANGO_DEBUG=False`, so a cloud deployment cannot silently fall back to the local SQLite database. Never deploy with `DEBUG=True` or the fallback local development secret. The application does not itself provision hosting or a cloud database. HTTPS, environment variables, database access controls, backups and availability depend on provider setup. A live URL must be tested before describing the app as deployed.

### Architecture and ER diagram

The `/architecture/` page shows the browser → Django application → database architecture and the local-vs-cloud distinction. The principal relationships are:

```text
User 1 ─── * Vehicle 1 ─── * Booking * ─── 1 ParkingSlot * ─── 1 ParkingLocation
                    └── * Payment
User 1 ─── * ActivityLog
```

The SQLite database on a developer's computer is local storage, not a cloud database. In a cloud deployment, authorized browser users reach the same hosted application, and it reads/writes one configured hosted database. See `docs/CLOUD_DEPLOYMENT.md` for provider-oriented settings details.

## Troubleshooting

- **`python` not recognized:** install Python from python.org and enable the installer option to add Python to PATH; restart VS Code.
- **Activation is blocked:** use the process-scoped execution policy command above; it does not change machine policy.
- **Django import error:** activate `.venv` and rerun `pip install -r requirements.txt`.
- **No available slots:** run `python manage.py seed_demo_data`, choose a future date/time during location hours, and make sure the vehicle category matches a slot.
- **Login fails:** log in with the email entered at registration or superuser creation; Django passwords are case-sensitive.
- **Static files look missing in production:** verify `collectstatic` ran and check provider build output and `ALLOWED_HOSTS`.
- **PostgreSQL connection error:** check the private `DATABASE_URL`, network access and database availability; local development uses SQLite when `DATABASE_URL` is empty.
- **Database schema error:** run `python manage.py migrate`.
- **Port already in use:** use `python manage.py runserver 8001` and visit port 8001.

## Main paths

- `config/`: Django settings and deployment entry points
- `core/`: user, parking, booking, payment and activity models, views and tests
- `templates/`: responsive HTML pages
- `static/css/site.css`: project styling
- `core/management/commands/seed_demo_data.py`: repeatable demo-data loader
- `docs/CLOUD_DEPLOYMENT.md`: deployment checklist and architecture notes
