from django.contrib import admin
from django.contrib.auth.admin import UserAdmin

from .models import ActivityLog, Booking, ParkingLocation, ParkingSlot, Payment, User, Vehicle


@admin.register(User)
class CloudParkUserAdmin(UserAdmin):
    ordering = ("email",)
    list_display = ("email", "first_name", "role", "is_staff", "is_active")
    list_filter = ("role", "is_staff", "is_active")
    search_fields = ("email", "first_name")
    fieldsets = (
        (None, {"fields": ("email", "password")}),
        ("Personal info", {"fields": ("first_name", "last_name", "phone")}),
        ("Permissions", {"fields": ("role", "is_active", "is_staff", "is_superuser", "groups", "user_permissions")}),
        ("Important dates", {"fields": ("last_login", "date_joined")}),
    )
    add_fieldsets = (
        (None, {"classes": ("wide",), "fields": ("email", "first_name", "password1", "password2")}),
    )
    filter_horizontal = ("groups", "user_permissions")


@admin.register(ParkingLocation)
class ParkingLocationAdmin(admin.ModelAdmin):
    list_display = ("name", "address", "price_per_hour", "total_capacity", "is_active")
    list_filter = ("is_active",)
    search_fields = ("name", "address")


@admin.register(ParkingSlot)
class ParkingSlotAdmin(admin.ModelAdmin):
    list_display = ("number", "location", "vehicle_category", "is_active")
    list_filter = ("location", "vehicle_category", "is_active")
    search_fields = ("number", "location__name")


@admin.register(Vehicle)
class VehicleAdmin(admin.ModelAdmin):
    list_display = ("registration", "user", "category", "created_at")
    search_fields = ("registration", "user__email")


@admin.register(Booking)
class BookingAdmin(admin.ModelAdmin):
    list_display = ("reference", "user", "slot", "starts_at", "status", "amount")
    list_filter = ("status", "slot__location")
    search_fields = ("reference", "user__email", "vehicle_registration")
    readonly_fields = ("reference", "created_at", "updated_at")


@admin.register(Payment)
class PaymentAdmin(admin.ModelAdmin):
    list_display = ("booking", "amount", "method", "status", "paid_at")
    list_filter = ("status", "method")


@admin.register(ActivityLog)
class ActivityLogAdmin(admin.ModelAdmin):
    list_display = ("action", "actor", "details", "created_at")
    readonly_fields = ("actor", "action", "details", "created_at")
