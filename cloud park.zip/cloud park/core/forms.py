﻿from django import forms
from django.contrib.auth import authenticate
from django.contrib.auth.forms import AuthenticationForm, PasswordChangeForm
from django.contrib.auth.password_validation import validate_password

from .models import ParkingLocation, ParkingSlot, User


class RegistrationForm(forms.ModelForm):
    password = forms.CharField(widget=forms.PasswordInput, validators=[validate_password])
    confirm_password = forms.CharField(widget=forms.PasswordInput, label="Confirm password")

    class Meta:
        model = User
        fields = ["first_name", "email", "phone"]
        widgets = {"email": forms.EmailInput(attrs={"autocomplete": "email"})}

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        for field in self.fields.values():
            field.widget.attrs["class"] = "form-control"

    def clean_email(self):
        email = self.cleaned_data["email"].strip().lower()
        if User.objects.filter(email__iexact=email).exists():
            raise forms.ValidationError("An account with this email already exists.")
        return email

    def clean(self):
        data = super().clean()
        if data.get("password") and data.get("confirm_password"):
            if data["password"] != data["confirm_password"]:
                self.add_error("confirm_password", "The passwords do not match.")
        return data

    def save(self, commit=True):
        user = super().save(commit=False)
        user.set_password(self.cleaned_data["password"])
        user.role = User.Role.CUSTOMER
        if commit:
            user.save()
        return user


class ProfileForm(forms.ModelForm):
    class Meta:
        model = User
        fields = ["first_name", "email", "phone"]

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        for field in self.fields.values():
            field.widget.attrs["class"] = "form-control"

    def clean_email(self):
        email = self.cleaned_data["email"].strip().lower()
        if User.objects.filter(email__iexact=email).exclude(pk=self.instance.pk).exists():
            raise forms.ValidationError("An account with this email already exists.")
        return email


class EmailAuthenticationForm(AuthenticationForm):
    username = forms.EmailField(label="Email address")

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        for field in self.fields.values():
            field.widget.attrs["class"] = "form-control"

    def clean(self):
        email = self.cleaned_data.get("username")
        password = self.cleaned_data.get("password")
        if email and password:
            self.user_cache = authenticate(
                self.request, email=email.strip().lower(), password=password
            )
            if self.user_cache is None:
                raise forms.ValidationError("Email or password is incorrect.")
            self.confirm_login_allowed(self.user_cache)
        return self.cleaned_data


class BookingSearchForm(forms.Form):
    location = forms.ModelChoiceField(
        queryset=ParkingLocation.objects.none(), required=False, empty_label="Any location"
    )
    date = forms.DateField(widget=forms.DateInput(attrs={"type": "date"}))
    start_time = forms.TimeField(widget=forms.TimeInput(attrs={"type": "time"}))
    end_time = forms.TimeField(widget=forms.TimeInput(attrs={"type": "time"}))
    vehicle_category = forms.ChoiceField(choices=ParkingSlot.VehicleCategory.choices)

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields["location"].queryset = ParkingLocation.objects.filter(is_active=True)
        for field in self.fields.values():
            field.widget.attrs["class"] = (
                "form-select" if isinstance(field.widget, forms.Select) else "form-control"
            )


class LocationForm(forms.ModelForm):
    class Meta:
        model = ParkingLocation
        fields = [
            "name", "address", "description", "total_capacity", "price_per_hour",
            "opening_time", "closing_time", "is_active",
        ]
        widgets = {
            "opening_time": forms.TimeInput(attrs={"type": "time"}),
            "closing_time": forms.TimeInput(attrs={"type": "time"}),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        for field in self.fields.values():
            field.widget.attrs["class"] = (
                "form-select" if isinstance(field.widget, forms.Select) else "form-control"
            )

    def clean(self):
        data = super().clean()
        opening_time = data.get("opening_time")
        closing_time = data.get("closing_time")
        if opening_time and closing_time and opening_time >= closing_time:
            self.add_error("closing_time", "Closing time must be later than opening time.")
        capacity = data.get("total_capacity")
        if self.instance.pk and capacity is not None:
            existing_slots = self.instance.slots.count()
            if capacity < existing_slots:
                self.add_error(
                    "total_capacity",
                    f"Capacity cannot be less than the {existing_slots} existing slots.",
                )
        return data


class SlotForm(forms.ModelForm):
    class Meta:
        model = ParkingSlot
        fields = ["location", "number", "vehicle_category", "is_active"]

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        for field in self.fields.values():
            field.widget.attrs["class"] = (
                "form-select" if isinstance(field.widget, forms.Select) else "form-control"
            )

    def clean(self):
        data = super().clean()
        location = data.get("location")
        if location and (not self.instance.pk or self.instance.location_id != location.pk):
            existing = ParkingSlot.objects.filter(location=location)
            if self.instance.pk:
                existing = existing.exclude(pk=self.instance.pk)
            existing_slots = existing.count()
            if existing_slots >= location.total_capacity:
                self.add_error(
                    "location",
                    "This location has reached its configured total parking capacity.",
                )
        return data
