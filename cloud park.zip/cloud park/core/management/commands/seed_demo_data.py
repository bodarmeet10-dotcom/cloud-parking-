from datetime import time

from django.core.management.base import BaseCommand
from django.db import transaction

from core.models import ParkingLocation, ParkingSlot


class Command(BaseCommand):
    help = "Create clearly labelled sample CloudPark parking locations and slots."

    @transaction.atomic
    def handle(self, *args, **options):
        examples = [
            ("City Center Parking (Demo)", "Sample address, City Center", "₹45 sample hourly rate", 45),
            ("Shopping Mall Parking (Demo)", "Sample address, Shopping District", "₹50 sample hourly rate", 50),
            ("Railway Station Parking (Demo)", "Sample address, Station Road", "₹35 sample hourly rate", 35),
            ("University Campus Parking (Demo)", "Sample address, Campus Road", "₹20 sample hourly rate", 20),
            ("Business District Parking (Demo)", "Sample address, Business District", "₹40 sample hourly rate", 40),
        ]
        for name, address, description, rate in examples:
            location, _ = ParkingLocation.objects.get_or_create(
                name=name,
                defaults={
                    "address": address,
                    "description": f"{description}. Sample project data; not a verified facility.",
                    "total_capacity": 10,
                    "price_per_hour": rate,
                    "opening_time": time(6, 0),
                    "closing_time": time(23, 0),
                },
            )
            for number in range(1, 9):
                ParkingSlot.objects.get_or_create(
                    location=location,
                    number=f"C{number:02d}",
                    defaults={"vehicle_category": ParkingSlot.VehicleCategory.CAR},
                )
            for number in range(1, 3):
                ParkingSlot.objects.get_or_create(
                    location=location,
                    number=f"M{number:02d}",
                    defaults={"vehicle_category": ParkingSlot.VehicleCategory.MOTORCYCLE},
                )
        self.stdout.write(self.style.SUCCESS("Demo locations and slots are ready."))
