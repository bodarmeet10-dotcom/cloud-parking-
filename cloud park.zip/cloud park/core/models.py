﻿import uuid
from decimal import Decimal

from django.contrib.auth.base_user import BaseUserManager
from django.contrib.auth.models import AbstractUser
from django.core.validators import MinValueValidator
from django.db import models
from django.db.models import Q
from django.utils import timezone


class UserManager(BaseUserManager):
    use_in_migrations = True

    def _create_user(self, email, password, **extra_fields):
        if not email:
            raise ValueError("An email address is required.")
        user = self.model(email=self.normalize_email(email), **extra_fields)
        user.set_password(password)
        user.save(using=self._db)
        return user

    def create_user(self, email, password=None, **extra_fields):
        extra_fields.setdefault("role", User.Role.CUSTOMER)
        extra_fields.setdefault("is_staff", False)
        extra_fields.setdefault("is_superuser", False)
        return self._create_user(email, password, **extra_fields)

    def create_superuser(self, email, password=None, **extra_fields):
        extra_fields.setdefault("role", User.Role.ADMIN)
        extra_fields.setdefault("is_staff", True)
        extra_fields.setdefault("is_superuser", True)
        if extra_fields.get("is_staff") is not True:
            raise ValueError("A superuser must have is_staff=True.")
        if extra_fields.get("is_superuser") is not True:
            raise ValueError("A superuser must have is_superuser=True.")
        return self._create_user(email, password, **extra_fields)


class User(AbstractUser):
    class Role(models.TextChoices):
        CUSTOMER = "customer", "Customer"
        ADMIN = "admin", "Administrator"

    username = None
    email = models.EmailField(unique=True)
    first_name = models.CharField("full name", max_length=150)
    phone = models.CharField(max_length=30, blank=True)
    role = models.CharField(max_length=12, choices=Role.choices, default=Role.CUSTOMER)

    USERNAME_FIELD = "email"
    REQUIRED_FIELDS = ["first_name"]
    objects = UserManager()

    def __str__(self):
        return self.email


class ParkingLocation(models.Model):
    name = models.CharField(max_length=120)
    address = models.CharField(max_length=255)
    description = models.TextField(blank=True)
    total_capacity = models.PositiveIntegerField(default=0)
    price_per_hour = models.DecimalField(
        max_digits=8, decimal_places=2, validators=[MinValueValidator(Decimal("0.01"))]
    )
    opening_time = models.TimeField(default="06:00")
    closing_time = models.TimeField(default="23:00")
    is_active = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ["name"]
        indexes = [models.Index(fields=["is_active", "name"])]

    @property
    def available_slot_count(self):
        now = timezone.now()
        return self.slots.filter(is_active=True).exclude(
            bookings__status__in=[
                Booking.Status.PENDING,
                Booking.Status.CONFIRMED,
            ],
            bookings__starts_at__lt=now,
            bookings__ends_at__gt=now,
        ).distinct().count()

    def __str__(self):
        return self.name


class ParkingSlot(models.Model):
    class VehicleCategory(models.TextChoices):
        CAR = "car", "Car"
        MOTORCYCLE = "motorcycle", "Motorcycle"

    location = models.ForeignKey(
        ParkingLocation, on_delete=models.CASCADE, related_name="slots"
    )
    number = models.CharField(max_length=20)
    vehicle_category = models.CharField(
        max_length=12, choices=VehicleCategory.choices, default=VehicleCategory.CAR
    )
    is_active = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ["location__name", "number"]
        constraints = [
            models.UniqueConstraint(
                fields=["location", "number"], name="unique_slot_number_per_location"
            )
        ]
        indexes = [models.Index(fields=["location", "is_active"])]

    def __str__(self):
        return f"{self.location.name} · {self.number}"


class Vehicle(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name="vehicles")
    registration = models.CharField(max_length=20)
    category = models.CharField(max_length=12, choices=ParkingSlot.VehicleCategory.choices)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ["registration"]
        constraints = [
            models.UniqueConstraint(
                fields=["user", "registration"], name="unique_vehicle_per_user"
            )
        ]

    def __str__(self):
        return self.registration


class Booking(models.Model):
    class Status(models.TextChoices):
        PENDING = "pending", "Pending"
        CONFIRMED = "confirmed", "Confirmed"
        CANCELLED = "cancelled", "Cancelled"
        COMPLETED = "completed", "Completed"

    reference = models.UUIDField(default=uuid.uuid4, unique=True, editable=False)
    user = models.ForeignKey(User, on_delete=models.PROTECT, related_name="bookings")
    slot = models.ForeignKey(ParkingSlot, on_delete=models.PROTECT, related_name="bookings")
    vehicle = models.ForeignKey(
        Vehicle, on_delete=models.PROTECT, related_name="bookings", null=True, blank=True
    )
    starts_at = models.DateTimeField()
    ends_at = models.DateTimeField()
    vehicle_registration = models.CharField(max_length=20)
    vehicle_category = models.CharField(
        max_length=12, choices=ParkingSlot.VehicleCategory.choices
    )
    hourly_rate = models.DecimalField(max_digits=8, decimal_places=2)
    duration_hours = models.PositiveIntegerField()
    amount = models.DecimalField(max_digits=10, decimal_places=2)
    status = models.CharField(
        max_length=12, choices=Status.choices, default=Status.CONFIRMED
    )
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ["-created_at"]
        indexes = [
            models.Index(fields=["slot", "status", "starts_at", "ends_at"]),
            models.Index(fields=["user", "starts_at"]),
            models.Index(fields=["status", "created_at"]),
        ]
        constraints = [
            models.CheckConstraint(
                condition=Q(ends_at__gt=models.F("starts_at")),
                name="booking_end_after_start",
            )
        ]

    @staticmethod
    def calculate_duration_hours(starts_at, ends_at):
        seconds = (ends_at - starts_at).total_seconds()
        if seconds <= 0:
            raise ValueError("Booking end must be after its start.")
        return max(1, int((seconds + 3599) // 3600))

    @property
    def location(self):
        return self.slot.location

    def __str__(self):
        return f"{self.reference} ({self.get_status_display()})"


class Payment(models.Model):
    class Status(models.TextChoices):
        SIMULATED = "simulated", "Simulated (not charged)"
        VERIFIED = "verified", "Verified"
        FAILED = "failed", "Failed"

    booking = models.ForeignKey(Booking, on_delete=models.PROTECT, related_name="payments")
    amount = models.DecimalField(max_digits=10, decimal_places=2)
    method = models.CharField(max_length=30, default="demo")
    status = models.CharField(
        max_length=12, choices=Status.choices, default=Status.SIMULATED
    )
    transaction_reference = models.UUIDField(default=uuid.uuid4, unique=True)
    paid_at = models.DateTimeField(default=timezone.now)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["-created_at"]
        constraints = [
            models.UniqueConstraint(
                fields=["booking"], name="unique_payment_per_booking"
            )
        ]

    def __str__(self):
        return str(self.transaction_reference)


class ActivityLog(models.Model):
    actor = models.ForeignKey(
        User,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="activity_logs",
    )
    action = models.CharField(max_length=64)
    details = models.TextField(blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["-created_at"]

    def __str__(self):
        return f"{self.actor or 'system'}: {self.action}"
