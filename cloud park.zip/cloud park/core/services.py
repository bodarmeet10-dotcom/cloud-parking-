from datetime import datetime, timedelta
from decimal import Decimal, ROUND_HALF_UP

from django.conf import settings
from django.db import transaction
from django.db.models import Q
from django.utils import timezone

from .models import ActivityLog, Booking, ParkingSlot, Payment, Vehicle


class BookingError(Exception):
    pass


def requested_datetimes(date, start_time, end_time):
    start = timezone.make_aware(datetime.combine(date, start_time))
    end = timezone.make_aware(datetime.combine(date, end_time))
    return start, end


def validate_booking_window(location, starts_at, ends_at):
    now = timezone.now()
    if starts_at <= now:
        raise BookingError("Choose a future start time.")
    if ends_at <= starts_at:
        raise BookingError("End time must be later than start time.")
    if starts_at.date() != ends_at.date():
        raise BookingError("Bookings must start and end on the same day.")
    if starts_at.time() < location.opening_time or ends_at.time() > location.closing_time:
        raise BookingError(
            f"This location operates from {location.opening_time:%H:%M} "
            f"to {location.closing_time:%H:%M}."
        )


def available_slots(location, starts_at, ends_at, vehicle_category):
    slots = ParkingSlot.objects.filter(
        location=location, is_active=True, vehicle_category=vehicle_category
    ).exclude(
        bookings__status__in=[Booking.Status.PENDING, Booking.Status.CONFIRMED],
        bookings__starts_at__lt=ends_at,
        bookings__ends_at__gt=starts_at,
    )
    return slots.distinct()


def create_booking(*, user, slot_id, starts_at, ends_at, vehicle_registration):
    registration = (vehicle_registration or "").strip().upper()
    if not registration or len(registration) > 20 or not all(
        character.isalnum() or character in " -" for character in registration
    ):
        raise BookingError("Enter a valid vehicle registration (letters, numbers, spaces or hyphens).")
    with transaction.atomic():
        slot = ParkingSlot.objects.select_for_update().select_related("location").get(
            pk=slot_id, is_active=True, location__is_active=True
        )
        validate_booking_window(slot.location, starts_at, ends_at)
        overlaps = Booking.objects.filter(
            slot=slot,
            status__in=[Booking.Status.PENDING, Booking.Status.CONFIRMED],
            starts_at__lt=ends_at,
            ends_at__gt=starts_at,
        ).exists()
        if overlaps:
            raise BookingError("That slot was just reserved. Please choose another.")

        hours = Booking.calculate_duration_hours(starts_at, ends_at)
        rate = slot.location.price_per_hour
        amount = (rate * Decimal(hours)).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)
        vehicle, created = Vehicle.objects.get_or_create(
            user=user,
            registration=registration,
            defaults={"category": slot.vehicle_category},
        )
        if not created and vehicle.category != slot.vehicle_category:
            raise BookingError("That registration is already saved for a different vehicle category.")
        booking = Booking.objects.create(
            user=user,
            slot=slot,
            vehicle=vehicle,
            starts_at=starts_at,
            ends_at=ends_at,
            vehicle_registration=registration,
            vehicle_category=slot.vehicle_category,
            hourly_rate=rate,
            duration_hours=hours,
            amount=amount,
            status=Booking.Status.CONFIRMED,
        )
        ActivityLog.objects.create(
            actor=user, action="booking_created", details=str(booking.reference)
        )
        return booking


def cancel_booking(booking, actor):
    with transaction.atomic():
        booking = Booking.objects.select_for_update().get(pk=booking.pk)
        now = timezone.now()
        cutoff = now + timedelta(hours=settings.CANCELLATION_CUTOFF_HOURS)
        if booking.status != Booking.Status.CONFIRMED:
            raise BookingError("Only confirmed bookings can be cancelled.")
        if booking.starts_at <= cutoff:
            raise BookingError(
                f"Bookings can be cancelled at least {settings.CANCELLATION_CUTOFF_HOURS} "
                "hours before the start time."
            )
        booking.status = Booking.Status.CANCELLED
        booking.save(update_fields=["status", "updated_at"])
        ActivityLog.objects.create(
            actor=actor, action="booking_cancelled", details=str(booking.reference)
        )
        return booking


def record_demo_payment(booking, actor):
    with transaction.atomic():
        booking = Booking.objects.select_for_update().get(pk=booking.pk)
        if booking.status != Booking.Status.CONFIRMED:
            raise BookingError("Only confirmed bookings can have a demo payment recorded.")
        if booking.payments.filter(status=Payment.Status.SIMULATED).exists():
            raise BookingError("A demo payment has already been recorded for this booking.")
        payment = Payment.objects.create(
            booking=booking,
            amount=booking.amount,
            method="demo",
            status=Payment.Status.SIMULATED,
        )
        ActivityLog.objects.create(
            actor=actor, action="demo_payment_recorded",
            details=str(payment.transaction_reference),
        )
        return payment


def set_booking_status(booking, status, actor):
    transitions = {
        Booking.Status.CONFIRMED: {Booking.Status.CANCELLED, Booking.Status.COMPLETED},
        Booking.Status.PENDING: {Booking.Status.CONFIRMED, Booking.Status.CANCELLED},
    }
    with transaction.atomic():
        booking = Booking.objects.select_for_update().get(pk=booking.pk)
        if status not in transitions.get(booking.status, set()):
            raise BookingError("That booking status transition is not allowed.")
        booking.status = status
        booking.save(update_fields=["status", "updated_at"])
        ActivityLog.objects.create(
            actor=actor, action=f"booking_{status}", details=str(booking.reference)
        )
        return booking
