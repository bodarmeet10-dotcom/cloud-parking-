﻿from datetime import datetime, time, timedelta
from decimal import Decimal

from django.test import TestCase, override_settings
from django.urls import reverse
from django.utils import timezone

from .forms import LocationForm, RegistrationForm, SlotForm
from .models import Booking, ParkingLocation, ParkingSlot, Payment, User, Vehicle
from .services import BookingError, available_slots, cancel_booking, create_booking, record_demo_payment


class CloudParkTestCase(TestCase):
    def setUp(self):
        self.customer = User.objects.create_user(
            email="student@example.edu", password="CloudParkPass!123",
            first_name="Student",
        )
        self.location = ParkingLocation.objects.create(
            name="Campus Demo", address="Sample Road", total_capacity=4,
            price_per_hour=Decimal("40.00"), opening_time=time(6), closing_time=time(23),
        )
        self.slot = ParkingSlot.objects.create(
            location=self.location, number="C01",
            vehicle_category=ParkingSlot.VehicleCategory.CAR,
        )

    def future_window(self, hours_from_now=24, duration_hours=2):
        starts_at = (timezone.now() + timedelta(hours=hours_from_now)).replace(
            minute=0, second=0, microsecond=0
        )
        return starts_at, starts_at + timedelta(hours=duration_hours)

    def create_test_booking(self, **kwargs):
        starts_at, ends_at = self.future_window()
        return create_booking(
            user=self.customer, slot_id=self.slot.id, starts_at=starts_at,
            ends_at=ends_at, vehicle_registration="ka01ab1234", **kwargs,
        )

    def test_registration_creates_customer_and_hashes_password(self):
        form = RegistrationForm(data={
            "first_name": "A User", "email": "new@example.edu", "phone": "",
            "password": "A-Strong-Pass-734!", "confirm_password": "A-Strong-Pass-734!",
        })
        self.assertTrue(form.is_valid(), form.errors)
        user = form.save()
        self.assertEqual(user.role, User.Role.CUSTOMER)
        self.assertTrue(user.check_password("A-Strong-Pass-734!"))

    def test_registration_rejects_duplicate_email_and_mismatched_password(self):
        form = RegistrationForm(data={
            "first_name": "Other", "email": "STUDENT@example.edu", "phone": "",
            "password": "A-Strong-Pass-734!", "confirm_password": "different",
        })
        self.assertFalse(form.is_valid())
        self.assertIn("email", form.errors)
        self.assertIn("confirm_password", form.errors)

    def test_login_and_customer_dashboard_require_authentication(self):
        response = self.client.post(reverse("login"), {
            "username": "student@example.edu", "password": "CloudParkPass!123",
        })
        self.assertEqual(response.status_code, 302)
        self.assertEqual(self.client.get(reverse("dashboard")).status_code, 200)
        self.client.logout()
        response = self.client.get(reverse("dashboard"))
        self.assertEqual(response.status_code, 302)
        self.assertIn(reverse("login"), response.url)

    def test_customer_can_update_profile_without_changing_role(self):
        self.client.force_login(self.customer)
        response = self.client.post(reverse("profile"), {
            "first_name": "Updated Name",
            "email": self.customer.email,
            "phone": "555-0100",
        })
        self.assertEqual(response.status_code, 302)
        self.customer.refresh_from_db()
        self.assertEqual(self.customer.first_name, "Updated Name")
        self.assertEqual(self.customer.phone, "555-0100")
        self.assertEqual(self.customer.role, User.Role.CUSTOMER)

    def test_slot_availability_uses_overlapping_booking_times(self):
        starts_at, ends_at = self.future_window()
        self.assertTrue(available_slots(
            self.location, starts_at, ends_at, ParkingSlot.VehicleCategory.CAR
        ).filter(pk=self.slot.pk).exists())
        create_booking(
            user=self.customer, slot_id=self.slot.pk, starts_at=starts_at,
            ends_at=ends_at, vehicle_registration="KA01AB1234",
        )
        self.assertFalse(available_slots(
            self.location, starts_at + timedelta(minutes=30), ends_at,
            ParkingSlot.VehicleCategory.CAR,
        ).filter(pk=self.slot.pk).exists())
        self.assertTrue(available_slots(
            self.location, ends_at, ends_at + timedelta(hours=1),
            ParkingSlot.VehicleCategory.CAR,
        ).filter(pk=self.slot.pk).exists())

    def test_overlapping_booking_is_rejected_at_confirmation(self):
        starts_at, ends_at = self.future_window()
        create_booking(
            user=self.customer, slot_id=self.slot.pk, starts_at=starts_at,
            ends_at=ends_at, vehicle_registration="KA01AB1234",
        )
        with self.assertRaises(BookingError):
            create_booking(
                user=self.customer, slot_id=self.slot.pk,
                starts_at=starts_at + timedelta(minutes=15), ends_at=ends_at,
                vehicle_registration="KA02CD9876",
            )

    def test_rejects_past_and_invalid_booking_windows(self):
        with self.assertRaises(BookingError):
            create_booking(
                user=self.customer, slot_id=self.slot.pk,
                starts_at=timezone.now() - timedelta(hours=1),
                ends_at=timezone.now() + timedelta(hours=1),
                vehicle_registration="KA01AB1234",
            )
        starts_at = timezone.make_aware(datetime.combine(
            timezone.localdate() + timedelta(days=1), time(22, 45)
        ))
        with self.assertRaises(BookingError):
            create_booking(
                user=self.customer, slot_id=self.slot.pk, starts_at=starts_at,
                ends_at=starts_at + timedelta(minutes=30),
                vehicle_registration="KA01AB1234",
            )
        starts_at, _ = self.future_window()
        with self.assertRaises(BookingError):
            create_booking(
                user=self.customer, slot_id=self.slot.pk, starts_at=starts_at,
                ends_at=starts_at, vehicle_registration="KA01AB1234",
            )

    def test_price_rounds_up_each_started_hour_and_is_backend_computed(self):
        starts_at, _ = self.future_window()
        booking = create_booking(
            user=self.customer, slot_id=self.slot.pk, starts_at=starts_at,
            ends_at=starts_at + timedelta(minutes=61),
            vehicle_registration="KA01AB1234",
        )
        self.assertEqual(booking.duration_hours, 2)
        self.assertEqual(booking.amount, Decimal("80.00"))
        self.assertEqual(Booking.objects.get(pk=booking.pk).hourly_rate, Decimal("40.00"))

    def test_booking_confirmation_view_rechecks_and_saves_booking(self):
        starts_at, ends_at = self.future_window()
        self.client.force_login(self.customer)
        response = self.client.post(reverse("booking_create"), {
            "slot_id": self.slot.pk,
            "starts_at": starts_at.replace(tzinfo=None).isoformat(timespec="minutes"),
            "ends_at": ends_at.replace(tzinfo=None).isoformat(timespec="minutes"),
            "vehicle_registration": "KA01AB1234",
        })
        self.assertEqual(response.status_code, 302)
        booking = Booking.objects.get()
        self.assertEqual(booking.status, Booking.Status.CONFIRMED)
        self.assertEqual(booking.amount, Decimal("80.00"))
        self.assertEqual(booking.vehicle.registration, "KA01AB1234")

    def test_vehicle_is_reused_and_cannot_change_category(self):
        starts_at, ends_at = self.future_window()
        create_booking(
            user=self.customer, slot_id=self.slot.pk, starts_at=starts_at,
            ends_at=ends_at, vehicle_registration="KA01AB1234",
        )
        second_slot = ParkingSlot.objects.create(
            location=self.location, number="M01",
            vehicle_category=ParkingSlot.VehicleCategory.MOTORCYCLE,
        )
        with self.assertRaises(BookingError):
            create_booking(
                user=self.customer, slot_id=second_slot.pk, starts_at=starts_at,
                ends_at=ends_at, vehicle_registration="KA01AB1234",
            )
        self.assertEqual(Vehicle.objects.filter(user=self.customer).count(), 1)

    def test_cancellation_rule_preserves_booking_record(self):
        starts_at, ends_at = self.future_window()
        booking = create_booking(
            user=self.customer, slot_id=self.slot.pk, starts_at=starts_at,
            ends_at=ends_at, vehicle_registration="KA01AB1234",
        )
        cancel_booking(booking, self.customer)
        booking.refresh_from_db()
        self.assertEqual(booking.status, Booking.Status.CANCELLED)
        self.assertTrue(Booking.objects.filter(reference=booking.reference).exists())

    @override_settings(CANCELLATION_CUTOFF_HOURS=48)
    def test_cancellation_is_rejected_inside_configured_cutoff(self):
        starts_at = timezone.make_aware(datetime.combine(
            timezone.localdate() + timedelta(days=1), time(10, 0)
        ))
        booking = create_booking(
            user=self.customer, slot_id=self.slot.pk, starts_at=starts_at,
            ends_at=starts_at + timedelta(hours=1),
            vehicle_registration="KA01AB1234",
        )
        with self.assertRaises(BookingError):
            cancel_booking(booking, self.customer)
        booking.refresh_from_db()
        self.assertEqual(booking.status, Booking.Status.CONFIRMED)

    def test_customer_cannot_view_another_users_booking(self):
        starts_at, ends_at = self.future_window()
        booking = create_booking(
            user=self.customer, slot_id=self.slot.pk, starts_at=starts_at,
            ends_at=ends_at, vehicle_registration="KA01AB1234",
        )
        other = User.objects.create_user(
            email="other@example.edu", password="CloudParkPass!123", first_name="Other"
        )
        self.client.force_login(other)
        response = self.client.get(reverse("booking_detail", args=[booking.reference]))
        self.assertEqual(response.status_code, 403)

    def test_admin_area_requires_administrator(self):
        self.client.force_login(self.customer)
        self.assertEqual(self.client.get(reverse("admin_dashboard")).status_code, 302)
        administrator = User.objects.create_superuser(
            email="admin@example.edu", password="AdminPass!123", first_name="Admin"
        )
        self.client.force_login(administrator)
        self.assertEqual(self.client.get(reverse("admin_dashboard")).status_code, 200)

    def test_admin_management_pages_and_csv_render(self):
        administrator = User.objects.create_superuser(
            email="admin@example.edu", password="AdminPass!123", first_name="Admin"
        )
        self.client.force_login(administrator)
        for name in (
            "admin_locations", "admin_slots", "admin_bookings", "admin_users",
            "admin_payments",
        ):
            with self.subTest(page=name):
                self.assertEqual(self.client.get(reverse(name)).status_code, 200)
        csv_response = self.client.get(reverse("admin_csv"))
        self.assertEqual(csv_response.status_code, 200)
        self.assertEqual(csv_response["Content-Type"], "text/csv; charset=utf-8")

    def test_simulated_payment_is_not_a_verified_collection(self):
        starts_at, ends_at = self.future_window()
        booking = create_booking(
            user=self.customer, slot_id=self.slot.pk, starts_at=starts_at,
            ends_at=ends_at, vehicle_registration="KA01AB1234",
        )
        payment = record_demo_payment(booking, self.customer)
        self.assertEqual(payment.status, Payment.Status.SIMULATED)
        self.assertEqual(payment.amount, booking.amount)
        with self.assertRaises(BookingError):
            record_demo_payment(booking, self.customer)

    def test_customer_booking_payment_and_cancellation_http_workflow(self):
        starts_at, ends_at = self.future_window()
        booking = create_booking(
            user=self.customer, slot_id=self.slot.pk, starts_at=starts_at,
            ends_at=ends_at, vehicle_registration="KA01AB1234",
        )
        self.client.force_login(self.customer)
        detail = self.client.get(reverse("booking_detail", args=[booking.reference]))
        self.assertEqual(detail.status_code, 200)
        response = self.client.post(reverse("demo_payment", args=[booking.reference]))
        self.assertEqual(response.status_code, 302)
        self.assertTrue(booking.payments.filter(status=Payment.Status.SIMULATED).exists())
        response = self.client.post(reverse("booking_cancel", args=[booking.reference]))
        self.assertEqual(response.status_code, 302)
        booking.refresh_from_db()
        self.assertEqual(booking.status, Booking.Status.CANCELLED)

    def test_health_check_uses_application_database(self):
        response = self.client.get(reverse("health"))
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.json(), {"status": "ok"})

    def test_parking_location_creation_through_admin_form(self):
        administrator = User.objects.create_superuser(
            email="admin@example.edu", password="AdminPass!123", first_name="Admin"
        )
        self.client.force_login(administrator)
        response = self.client.post(reverse("admin_location_create"), {
            "name": "New Demo", "address": "Example Avenue", "description": "Test",
            "total_capacity": 12, "price_per_hour": "30.00", "opening_time": "06:00",
            "closing_time": "22:00", "is_active": "on",
        })
        self.assertEqual(response.status_code, 302)
        self.assertTrue(ParkingLocation.objects.filter(name="New Demo").exists())

    def test_location_and_slot_forms_enforce_capacity_and_hours(self):
        location_form = LocationForm(data={
            "name": "Invalid hours", "address": "Sample", "description": "",
            "total_capacity": 2, "price_per_hour": "10.00",
            "opening_time": "22:00", "closing_time": "06:00", "is_active": "on",
        })
        self.assertFalse(location_form.is_valid())
        self.assertIn("closing_time", location_form.errors)
        slot_form = SlotForm(data={
            "location": self.location.pk, "number": "C02",
            "vehicle_category": "car", "is_active": "on",
        })
        self.location.total_capacity = 1
        self.location.save(update_fields=["total_capacity"])
        self.assertFalse(slot_form.is_valid())
        self.assertIn("location", slot_form.errors)

    def test_availability_endpoint_returns_database_slots(self):
        starts_at, ends_at = self.future_window()
        response = self.client.get(reverse("availability_api"), {
            "location": self.location.id,
            "date": starts_at.date().isoformat(),
            "start_time": starts_at.strftime("%H:%M"),
            "end_time": ends_at.strftime("%H:%M"),
            "vehicle_category": "car",
        })
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.json()["slots"][0]["number"], "C01")
