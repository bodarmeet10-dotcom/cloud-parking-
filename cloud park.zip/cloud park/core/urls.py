from django.contrib.auth import views as auth_views
from django.urls import path

from . import views
from .forms import EmailAuthenticationForm

urlpatterns = [
    path("", views.home, name="home"),
    path("health/", views.health, name="health"),
    path("architecture/", views.architecture, name="architecture"),
    path("register/", views.register, name="register"),
    path(
        "login/",
        auth_views.LoginView.as_view(
            template_name="core/form_page.html",
            authentication_form=EmailAuthenticationForm,
            extra_context={"page_title": "Welcome back", "submit_label": "Sign in"},
        ),
        name="login",
    ),
    path("logout/", auth_views.LogoutView.as_view(), name="logout"),
    path(
        "password-change/",
        auth_views.PasswordChangeView.as_view(
            template_name="core/form_page.html",
            success_url="/dashboard/",
            extra_context={"page_title": "Change password", "submit_label": "Update password"},
        ),
        name="password_change",
    ),
    path("parking/", views.parking_list, name="parking_list"),
    path("parking/<int:location_id>/", views.location_detail, name="location_detail"),
    path("api/availability/", views.availability_api, name="availability_api"),
    path("dashboard/", views.dashboard, name="dashboard"),
    path("profile/", views.profile, name="profile"),
    path("bookings/search/", views.booking_search, name="booking_search"),
    path("bookings/create/", views.booking_create, name="booking_create"),
    path("bookings/<uuid:reference>/", views.booking_detail, name="booking_detail"),
    path("bookings/<uuid:reference>/cancel/", views.booking_cancel, name="booking_cancel"),
    path("bookings/<uuid:reference>/demo-payment/", views.demo_payment, name="demo_payment"),
    path("admin-dashboard/", views.admin_dashboard, name="admin_dashboard"),
    path("admin-dashboard/locations/", views.admin_locations, name="admin_locations"),
    path(
        "admin-dashboard/locations/new/",
        views.admin_location_create,
        name="admin_location_create",
    ),
    path(
        "admin-dashboard/locations/<int:location_id>/edit/",
        views.admin_location_edit,
        name="admin_location_edit",
    ),
    path("admin-dashboard/slots/", views.admin_slots, name="admin_slots"),
    path(
        "admin-dashboard/slots/<int:slot_id>/edit/",
        views.admin_slot_edit,
        name="admin_slot_edit",
    ),
    path("admin-dashboard/bookings/", views.admin_bookings, name="admin_bookings"),
    path(
        "admin-dashboard/bookings/<uuid:reference>/status/",
        views.admin_booking_status,
        name="admin_booking_status",
    ),
    path("admin-dashboard/users/", views.admin_users, name="admin_users"),
    path("admin-dashboard/payments/", views.admin_payments, name="admin_payments"),
    path("admin-dashboard/reports.csv", views.admin_csv, name="admin_csv"),
]
