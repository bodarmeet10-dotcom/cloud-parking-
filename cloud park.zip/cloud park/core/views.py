import csv
import logging
from datetime import date, datetime, time, timedelta
from decimal import Decimal
from decimal import InvalidOperation

from django.contrib import messages
from django.contrib.auth import login
from django.contrib.auth.decorators import login_required, user_passes_test
from django.core.paginator import Paginator
from django.db.models import Count, Exists, OuterRef, Q, Sum
from django.db.models.functions import TruncDate
from django.http import HttpResponse, JsonResponse
from django.shortcuts import get_object_or_404, redirect, render
from django.utils import timezone
from django.views.decorators.http import require_GET, require_POST

from .forms import BookingSearchForm, LocationForm, ProfileForm, RegistrationForm, SlotForm
from .models import ActivityLog, Booking, ParkingLocation, ParkingSlot, Payment, User
from .services import (
    BookingError,
    available_slots,
    cancel_booking,
    create_booking,
    record_demo_payment,
    requested_datetimes,
    set_booking_status,
    validate_booking_window,
)

logger = logging.getLogger(__name__)


def home(request):
    locations = ParkingLocation.objects.filter(is_active=True)
    context = {
        "locations": locations[:5],
        "location_count": locations.count(),
        "slot_count": ParkingSlot.objects.filter(is_active=True, location__is_active=True).count(),
        "booking_count": Booking.objects.filter(
            status__in=[Booking.Status.CONFIRMED, Booking.Status.COMPLETED]
        ).count(),
        "search_form": BookingSearchForm(initial={
            "date": timezone.localdate() + timedelta(days=1),
            "start_time": "10:00",
            "end_time": "11:00",
        }),
    }
    return render(request, "core/home.html", context)


@require_GET
def health(request):
    from django.db import connection

    try:
        with connection.cursor() as cursor:
            cursor.execute("SELECT 1")
            cursor.fetchone()
    except Exception:
        logger.exception("Health check database query failed")
        return JsonResponse({"status": "unhealthy"}, status=503)
    return JsonResponse({"status": "ok"})


def architecture(request):
    return render(request, "core/architecture.html")


def register(request):
    if request.user.is_authenticated:
        return redirect("dashboard")
    form = RegistrationForm(request.POST or None)
    if request.method == "POST" and form.is_valid():
        user = form.save()
        login(request, user)
        messages.success(request, "Your CloudPark account is ready.")
        return redirect("dashboard")
    return render(
        request,
        "core/form_page.html",
        {"form": form, "page_title": "Create your account", "submit_label": "Register"},
    )


def parking_list(request):
    locations = ParkingLocation.objects.filter(is_active=True)
    minimum = request.GET.get("min_price", "").strip()
    maximum = request.GET.get("max_price", "").strip()
    query = request.GET.get("q", "").strip()
    if query:
        locations = locations.filter(name__icontains=query) | locations.filter(
            address__icontains=query
        )
    if minimum:
        try:
            minimum_value = Decimal(minimum)
            if not minimum_value.is_finite() or minimum_value < 0:
                raise InvalidOperation
            locations = locations.filter(price_per_hour__gte=minimum_value)
        except (InvalidOperation, ValueError):
            messages.error(request, "Minimum price must be a valid number.")
    if maximum:
        try:
            maximum_value = Decimal(maximum)
            if not maximum_value.is_finite() or maximum_value < 0:
                raise InvalidOperation
            locations = locations.filter(price_per_hour__lte=maximum_value)
        except (InvalidOperation, ValueError):
            messages.error(request, "Maximum price must be a valid number.")
    available_only = request.GET.get("available") == "on"
    if available_only:
        now = timezone.now()
        available_slot = ParkingSlot.objects.filter(
            location_id=OuterRef("pk"), is_active=True
        ).exclude(
            bookings__status=Booking.Status.CONFIRMED,
            bookings__starts_at__lte=now,
            bookings__ends_at__gt=now,
        )
        locations = locations.filter(Exists(available_slot))
    return render(
        request,
        "core/parking_list.html",
        {
            "locations": locations.distinct(),
            "query": query,
            "minimum": minimum,
            "maximum": maximum,
            "available_only": available_only,
        },
    )


def location_detail(request, location_id):
    location = get_object_or_404(ParkingLocation, pk=location_id, is_active=True)
    now = timezone.now()
    active_bookings = Booking.objects.filter(
        slot__location=location,
        status=Booking.Status.CONFIRMED,
        ends_at__gt=now,
    ).values_list("slot_id", "starts_at")
    current_slot_state = {}
    for slot_id, starts_at in active_bookings:
        state = "occupied" if starts_at <= now else "reserved"
        if current_slot_state.get(slot_id) != "occupied":
            current_slot_state[slot_id] = state
    slot_items = [
        {
            "slot": slot,
            "state": (
                "inactive" if not slot.is_active
                else current_slot_state.get(slot.id, "available")
            ),
        }
        for slot in location.slots.all()
    ]
    return render(
        request,
        "core/location_detail.html",
        {
            "location": location,
            "slots": slot_items,
            "active_slot_count": location.slots.filter(is_active=True).count(),
            "search_form": BookingSearchForm(initial={
                "location": location,
                "date": timezone.localdate() + timedelta(days=1),
                "start_time": "10:00",
                "end_time": "11:00",
            }),
        },
    )


@require_GET
def availability_api(request):
    try:
        location = get_object_or_404(
            ParkingLocation, pk=request.GET.get("location"), is_active=True
        )
        booking_date = date.fromisoformat(request.GET["date"])
        start_time = time.fromisoformat(request.GET["start_time"])
        end_time = time.fromisoformat(request.GET["end_time"])
        category = request.GET.get("vehicle_category", ParkingSlot.VehicleCategory.CAR)
        if category not in ParkingSlot.VehicleCategory.values:
            raise ValueError("Unknown vehicle category.")
        starts_at, ends_at = requested_datetimes(booking_date, start_time, end_time)
        validate_booking_window(location, starts_at, ends_at)
    except (KeyError, TypeError, ValueError, BookingError) as exc:
        return JsonResponse({"error": str(exc) or "Invalid availability search."}, status=400)
    slots = available_slots(location, starts_at, ends_at, category)
    return JsonResponse({
        "slots": [
            {"id": slot.id, "number": slot.number, "category": slot.get_vehicle_category_display()}
            for slot in slots
        ]
    })


@login_required
def dashboard(request):
    bookings = Booking.objects.filter(user=request.user).select_related("slot__location")
    now = timezone.now()
    upcoming = bookings.filter(status=Booking.Status.CONFIRMED, starts_at__gte=now)
    context = {
        "total_count": bookings.count(),
        "upcoming_count": upcoming.count(),
        "completed_count": bookings.filter(status=Booking.Status.COMPLETED).count(),
        "cancelled_count": bookings.filter(status=Booking.Status.CANCELLED).count(),
        "upcoming": upcoming.order_by("starts_at")[:5],
        "recent": bookings[:10],
    }
    return render(request, "core/dashboard.html", context)


@login_required
def profile(request):
    form = ProfileForm(request.POST or None, instance=request.user)
    if request.method == "POST" and form.is_valid():
        form.save()
        messages.success(request, "Your profile has been updated.")
        return redirect("profile")
    return render(
        request, "core/form_page.html",
        {"form": form, "page_title": "Your profile", "submit_label": "Save profile"},
    )


@login_required
def booking_search(request):
    form = BookingSearchForm(request.GET or None)
    slots = []
    error = ""
    if form.is_bound and form.is_valid():
        data = form.cleaned_data
        location = data["location"]
        if not location:
            error = "Choose a parking location to view available slots."
        else:
            starts_at, ends_at = requested_datetimes(
                data["date"], data["start_time"], data["end_time"]
            )
            try:
                validate_booking_window(location, starts_at, ends_at)
                slots = list(
                    available_slots(
                        location, starts_at, ends_at, data["vehicle_category"]
                    )
                )
                if not slots:
                    error = "No slots are available for this time. Try another time or location."
            except BookingError as exc:
                error = str(exc)
    return render(
        request,
        "core/booking_search.html",
        {"form": form, "slots": slots, "error": error},
    )


@login_required
@require_POST
def booking_create(request):
    try:
        starts_at = timezone.make_aware(
            datetime.fromisoformat(request.POST["starts_at"])
        )
        ends_at = timezone.make_aware(
            datetime.fromisoformat(request.POST["ends_at"])
        )
        booking = create_booking(
            user=request.user,
            slot_id=int(request.POST["slot_id"]),
            starts_at=starts_at,
            ends_at=ends_at,
            vehicle_registration=request.POST["vehicle_registration"],
        )
    except (KeyError, ValueError, TypeError, ParkingSlot.DoesNotExist, BookingError) as exc:
        messages.error(request, str(exc) or "We could not create this booking.")
        return redirect("booking_search")
    messages.success(request, "Your parking reservation is confirmed.")
    return redirect("booking_detail", reference=booking.reference)


@login_required
def booking_detail(request, reference):
    booking = get_object_or_404(
        Booking.objects.select_related("slot__location", "user").prefetch_related("payments"),
        reference=reference,
    )
    if booking.user_id != request.user.id and not is_administrator(request.user):
        from django.core.exceptions import PermissionDenied

        raise PermissionDenied
    return render(request, "core/booking_detail.html", {"booking": booking})


@login_required
@require_POST
def booking_cancel(request, reference):
    booking = get_object_or_404(Booking, reference=reference)
    if booking.user_id != request.user.id and not is_administrator(request.user):
        from django.core.exceptions import PermissionDenied

        raise PermissionDenied
    try:
        cancel_booking(booking, request.user)
    except BookingError as exc:
        messages.error(request, str(exc))
    else:
        messages.success(request, "Your reservation has been cancelled.")
    return redirect("booking_detail", reference=reference)


@login_required
@require_POST
def demo_payment(request, reference):
    booking = get_object_or_404(Booking, reference=reference, user=request.user)
    try:
        record_demo_payment(booking, request.user)
    except BookingError as exc:
        messages.error(request, str(exc))
    else:
        messages.success(request, "Simulated payment recorded. No money was charged.")
    return redirect("booking_detail", reference=reference)


def is_administrator(user):
    return user.is_authenticated and user.is_staff and user.role == User.Role.ADMIN


administrator_required = user_passes_test(is_administrator, login_url="login")


@administrator_required
def admin_dashboard(request):
    now = timezone.now()
    confirmed = Booking.objects.filter(
        status=Booking.Status.CONFIRMED, ends_at__gt=now
    )
    by_status = list(
        Booking.objects.values("status").annotate(total=Count("id")).order_by("status")
    )
    locations = ParkingLocation.objects.annotate(
        slot_total=Count("slots", filter=Q(slots__is_active=True), distinct=True),
        reserved_slots=Count(
            "slots",
            filter=Q(
                slots__is_active=True,
                slots__bookings__status=Booking.Status.CONFIRMED,
                slots__bookings__starts_at__lte=now,
                slots__bookings__ends_at__gt=now,
            ),
            distinct=True,
        ),
    )
    by_location = [
        {
            "name": location.name,
            "utilization": (
                round(location.reserved_slots * 100 / location.slot_total, 1)
                if location.slot_total else 0
            ),
        }
        for location in locations
    ]
    daily = list(
        Booking.objects.filter(
            created_at__date__gte=timezone.localdate() - timedelta(days=6)
        )
        .annotate(day=TruncDate("created_at"))
        .values("day")
        .annotate(total=Count("id"))
        .order_by("day")
    )
    revenue_daily = list(
        Payment.objects.filter(
            status__in=[Payment.Status.SIMULATED, Payment.Status.VERIFIED],
            paid_at__date__gte=timezone.localdate() - timedelta(days=6),
        )
        .annotate(day=TruncDate("paid_at"))
        .values("day")
        .annotate(total=Sum("amount"))
        .order_by("day")
    )
    context = {
        "location_count": ParkingLocation.objects.count(),
        "slot_count": ParkingSlot.objects.count(),
        "available_count": ParkingSlot.objects.filter(is_active=True, location__is_active=True)
        .exclude(
            bookings__status=Booking.Status.CONFIRMED,
            bookings__starts_at__lte=now,
            bookings__ends_at__gt=now,
        ).distinct().count(),
        "active_count": confirmed.count(),
        "completed_count": Booking.objects.filter(status=Booking.Status.COMPLETED).count(),
        "cancelled_count": Booking.objects.filter(status=Booking.Status.CANCELLED).count(),
        "simulated_revenue": Payment.objects.filter(status=Payment.Status.SIMULATED).aggregate(
            total=Sum("amount")
        )["total"] or Decimal("0.00"),
        "verified_revenue": Payment.objects.filter(status=Payment.Status.VERIFIED).aggregate(
            total=Sum("amount")
        )["total"] or Decimal("0.00"),
        "chart_status": by_status,
        "chart_locations": by_location,
        "chart_daily": daily,
        "chart_revenue": revenue_daily,
        "activities": ActivityLog.objects.select_related("actor")[:8],
    }
    return render(request, "core/admin_dashboard.html", context)


@administrator_required
def admin_locations(request):
    locations = ParkingLocation.objects.annotate(slot_total=Count("slots")).order_by("name")
    return render(request, "core/admin_locations.html", {"locations": locations})


@administrator_required
def admin_location_create(request):
    form = LocationForm(request.POST or None)
    if request.method == "POST" and form.is_valid():
        location = form.save()
        ActivityLog.objects.create(actor=request.user, action="location_created", details=location.name)
        messages.success(request, "Parking location created.")
        return redirect("admin_locations")
    return render(
        request, "core/form_page.html",
        {"form": form, "page_title": "Add parking location", "submit_label": "Save location"},
    )


@administrator_required
def admin_location_edit(request, location_id):
    location = get_object_or_404(ParkingLocation, pk=location_id)
    form = LocationForm(request.POST or None, instance=location)
    if request.method == "POST" and form.is_valid():
        form.save()
        ActivityLog.objects.create(actor=request.user, action="location_updated", details=location.name)
        messages.success(request, "Parking location updated.")
        return redirect("admin_locations")
    return render(
        request, "core/form_page.html",
        {"form": form, "page_title": "Edit parking location", "submit_label": "Save changes"},
    )


@administrator_required
def admin_slots(request):
    form = SlotForm(request.POST or None)
    if request.method == "POST" and form.is_valid():
        slot = form.save()
        ActivityLog.objects.create(actor=request.user, action="slot_created", details=str(slot))
        messages.success(request, "Parking slot created.")
        return redirect("admin_slots")
    slots = ParkingSlot.objects.select_related("location")
    return render(request, "core/admin_slots.html", {"form": form, "slots": slots})


@administrator_required
def admin_slot_edit(request, slot_id):
    slot = get_object_or_404(ParkingSlot, pk=slot_id)
    form = SlotForm(request.POST or None, instance=slot)
    if request.method == "POST" and form.is_valid():
        form.save()
        ActivityLog.objects.create(actor=request.user, action="slot_updated", details=str(slot))
        messages.success(request, "Parking slot updated.")
        return redirect("admin_slots")
    return render(
        request, "core/form_page.html",
        {"form": form, "page_title": "Edit parking slot", "submit_label": "Save slot"},
    )


@administrator_required
def admin_bookings(request):
    bookings = Booking.objects.select_related("user", "slot__location")
    status = request.GET.get("status", "")
    location = request.GET.get("location", "")
    date_filter = request.GET.get("date", "")
    query = request.GET.get("q", "").strip()
    if status in Booking.Status.values:
        bookings = bookings.filter(status=status)
    if location.isdigit():
        bookings = bookings.filter(slot__location_id=int(location))
    if date_filter:
        bookings = bookings.filter(starts_at__date=date_filter)
    if query:
        bookings = bookings.filter(
            Q(user__email__icontains=query) | Q(vehicle_registration__icontains=query)
            | Q(reference__icontains=query)
        )
    page = Paginator(bookings, 20).get_page(request.GET.get("page"))
    return render(
        request, "core/admin_bookings.html",
        {"page": page, "statuses": Booking.Status.choices,
         "locations": ParkingLocation.objects.all(), "filters": request.GET},
    )


@administrator_required
@require_POST
def admin_booking_status(request, reference):
    booking = get_object_or_404(Booking, reference=reference)
    status = request.POST.get("status", "")
    try:
        set_booking_status(booking, status, request.user)
    except BookingError as exc:
        messages.error(request, str(exc))
    else:
        messages.success(request, "Booking status updated.")
    return redirect("admin_bookings")


@administrator_required
def admin_users(request):
    users = User.objects.annotate(booking_total=Count("bookings")).order_by("-date_joined")
    page = Paginator(users, 25).get_page(request.GET.get("page"))
    return render(request, "core/admin_users.html", {"page": page})


@administrator_required
def admin_payments(request):
    payments = Payment.objects.select_related(
        "booking__user", "booking__slot__location"
    ).order_by("-created_at")
    page = Paginator(payments, 25).get_page(request.GET.get("page"))
    return render(request, "core/admin_payments.html", {"page": page})


@administrator_required
def admin_csv(request):
    response = HttpResponse(content_type="text/csv; charset=utf-8")
    response["Content-Disposition"] = 'attachment; filename="cloudpark-bookings.csv"'
    writer = csv.writer(response)
    writer.writerow([
        "Reference", "Customer email", "Location", "Slot", "Start", "End",
        "Vehicle registration", "Amount INR", "Status",
    ])
    def csv_value(value):
        value = str(value)
        if value.startswith(("=", "+", "-", "@", "\t", "\r")):
            return f"'{value}"
        return value

    for booking in Booking.objects.select_related(
        "user", "slot", "slot__location"
    ).order_by("-created_at"):
        writer.writerow([
            csv_value(booking.reference), csv_value(booking.user.email),
            csv_value(booking.slot.location.name), csv_value(booking.slot.number),
            booking.starts_at.isoformat(), booking.ends_at.isoformat(),
            csv_value(booking.vehicle_registration), booking.amount, booking.status,
        ])
    return response
