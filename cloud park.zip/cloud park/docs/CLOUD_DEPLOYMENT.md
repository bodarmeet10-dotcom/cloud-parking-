# Cloud Deployment and Architecture Notes

## Logical architecture

```text
Customer/admin browser
  └── HTTPS → Django web application
                ├── Django auth, permissions, CSRF and validation
                ├── Django ORM
                └── PostgreSQL (hosted shared reservation data)
                     └── WhiteNoise serves collected static assets
```

Local development uses `db.sqlite3` and Django's development server. It is not cloud storage. A deployment uses the provider's shared PostgreSQL service, so authorized people using the same hosted application see data persisted in that database. Browser code never receives database credentials or the Django secret.

## Configuration checklist

The project is prepared for Render but is not deployed. Create a Render PostgreSQL database and a Python web service connected to the project repository. Set the web service health-check path to `/health/`.

Set the web service build command to:

```text
pip install -r requirements.txt && python manage.py collectstatic --noinput && python manage.py migrate
```

Set its start command to:

```text
gunicorn config.wsgi:application --bind 0.0.0.0:$PORT
```

Configure `DJANGO_SECRET_KEY` (generate a unique secret in Render), `DJANGO_DEBUG=False`, `DJANGO_ALLOWED_HOSTS` (Render hostname only), `CSRF_TRUSTED_ORIGINS` (full HTTPS origin), and `DATABASE_URL` (the database's internal connection URL) in Render's environment settings. Optionally configure `CANCELLATION_CUTOFF_HOURS`. Production settings fail closed if the secret, host list, or PostgreSQL URL is missing. Never set these values in source files or commit `.env` or `db.sqlite3`.

The default production configuration enables secure session and CSRF cookies, HTTPS redirect, HSTS and content-type protection when debug is disabled. Only trust the actual HTTPS origins for the deployed app. `check --deploy` can report the optional HSTS preload warning; preload is intentionally not enabled because provider-managed hostnames may not meet preload-list requirements.

Build assets with:

```text
pip install -r requirements.txt && python manage.py collectstatic --noinput && python manage.py migrate
```

Run with the Render start command above, then open the actual assigned HTTPS site and check `/health/`. The endpoint verifies that Django can execute a database query. Only call the app deployed after that live URL and user flows have been successfully tested. Create an administrator through Render's secure shell with `python manage.py createsuperuser`. Set up backups, monitoring, log retention, database access policies and safe migration/release sequencing with the selected host.

## Entity relationships

```text
User (1) ── (*) Vehicle (1) ── (*) Booking (*) ── (1) ParkingSlot (*) ── (1) ParkingLocation
                         └── (*) Payment
User (1) ── (*) ActivityLog
```

Each booking stores its slot, customer, time range, vehicle registration, rate snapshot, duration, total and lifecycle state. A slot number is unique within its location. Active overlapping bookings are rejected inside an atomic server-side transaction. PostgreSQL row locking is used by `select_for_update()`; SQLite is for local single-user development and has weaker concurrent-write guarantees.

## Extension boundaries

Demo payments are stored with a `simulated` status and are not revenue collected. Integrate a real payment provider only through its official test/live modes, environment-based secrets and server-side signature verification; never store card number or CVV. IoT is not currently connected. A future device service should use unique revocable device credentials, authenticated server APIs, input validation, sensor health/last-seen data and auditable occupancy updates.
