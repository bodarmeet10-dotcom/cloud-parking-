document.addEventListener("DOMContentLoaded", () => {
  const form = document.getElementById("location-availability-form");
  const results = document.getElementById("availability-results");
  if (!form || !results) return;

  form.addEventListener("submit", async (event) => {
    event.preventDefault();
    const query = new URLSearchParams(new FormData(form));
    results.setAttribute("aria-busy", "true");
    results.textContent = "Checking the latest availability…";
    try {
      const response = await fetch(`${form.dataset.apiUrl}?${query.toString()}`, {
        headers: { Accept: "application/json" },
      });
      const payload = await response.json();
      results.replaceChildren();
      if (!response.ok) {
        results.textContent = payload.error || "Unable to check these times.";
        return;
      }
      if (payload.slots.length === 0) {
        results.textContent = "No slots are available for this period.";
        return;
      }
      const summary = document.createElement("p");
      summary.className = "text-success fw-semibold";
      summary.textContent = `${payload.slots.length} slot(s) available: ${payload.slots.map((slot) => slot.number).join(", ")}`;
      const link = document.createElement("a");
      link.className = "btn btn-outline-primary btn-sm";
      link.textContent = "Continue to reserve";
      link.href = `${form.action}?${query.toString()}`;
      results.append(summary, link);
    } catch {
      results.textContent = "Availability could not be checked. Please retry or use the parking search page.";
    } finally {
      results.removeAttribute("aria-busy");
    }
  });
});
